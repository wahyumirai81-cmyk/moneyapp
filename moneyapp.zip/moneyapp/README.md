# Reward App — Starter Project (Backend + Android)

Ini adalah **starting point** yang sudah lengkap secara struktur, tapi belum production-ready
sampai kamu isi kredensial asli (AdMob & payment gateway) dan deploy backend-nya.
Gue nggak bisa compile APK-nya di sini karena environment gue nggak punya Android SDK —
kamu perlu buka folder `android/` ini di Android Studio.

## Yang sudah ada
- **backend/** — Node.js + Express + SQLite: auth (register/login), reward per iklan
  (dengan verifikasi AdMob SSV supaya tidak bisa dicurangi), request withdraw.
- **android/** — Project Android Studio (Kotlin): login, tonton rewarded ad, lihat saldo, tarik saldo.

## Langkah supaya ini beneran jalan & bayar sungguhan

### 1. Daftar akun-akun yang dibutuhkan
| Kebutuhan | Untuk apa | Link |
|---|---|---|
| Akun AdMob | Nampilin iklan & dapat pendapatan dari Google | admob.google.com |
| Payment gateway (Xendit/Midtrans/Tripay) | Cairkan saldo user ke e-wallet/rekening | xendit.co / midtrans.com / tripay.co.id |
| Hosting backend | Jalankan server (Railway, Render, VPS) | railway.app / render.com |

**Penting soal uangnya:** pendapatan dari AdMob itu dibayar Google ke KAMU (pemilik app),
bukan otomatis ke user. Kamu yang harus nentuin margin — reward Rp500/iklan ke user
harus lebih kecil dari pendapatan rata-rata per iklan yang kamu dapat dari AdMob,
kalau tidak app ini akan terus rugi.

### 2. Setup backend
```bash
cd backend
cp .env.example .env
# edit .env, isi JWT_SECRET, ADMOB_SSV, dan PAYMENT_GATEWAY_API_KEY
npm install
npm start
```
Deploy ke Railway/Render, catat URL-nya (misal `https://appmu.up.railway.app`).

Di dashboard AdMob → Rewarded Ads → Server-side verification, daftarkan URL:
`https://appmu.up.railway.app/ads/admob-callback`

### 3. Dapetin APK-nya (otomatis, tanpa install apa-apa di laptop)
1. Bikin repo baru di GitHub, upload semua isi folder ini (termasuk folder `.github/`).
2. Setelah lu isi `REWARDED_AD_UNIT_ID`, `BASE_URL`, dan `APPLICATION_ID` (lihat langkah 4 di bawah),
   push ke branch `main`.
3. Buka tab **Actions** di repo GitHub lu → workflow "Build APK" akan otomatis jalan.
4. Setelah selesai (sekitar 3-5 menit), scroll ke bawah halaman run tersebut →
   di bagian **Artifacts** ada file `reward-app-debug-apk` → download, itu APK-nya.
5. Ini APK **debug** (buat testing). Untuk rilis ke Play Store, perlu di-sign
   pakai keystore — bisa gue bantu setup itu belakangan kalau udah sampai tahap itu.

### 4. Setup Android
1. Buka folder `android/` di Android Studio.
2. Di `AndroidManifest.xml`, ganti `APPLICATION_ID` dengan App ID asli dari AdMob.
3. Di `MainActivity.kt`, ganti `REWARDED_AD_UNIT_ID` dengan Ad Unit ID asli (yang sekarang
   masih ID **test** dari Google — aman untuk development tapi tidak menghasilkan uang).
4. Di `ApiClient.kt`, ganti `BASE_URL` dengan URL backend hasil deploy di langkah 2.
5. Build → Generate Signed Bundle/APK.

### 4. Yang masih perlu kamu lengkapi sendiri
- **Integrasi payment gateway asli** di `backend/src/routes/withdraw.js` (bagian `TODO`) —
  supaya withdraw benar-benar mencairkan dana, bukan cuma tercatat di database.
- **Panel admin** untuk approve/reject withdrawal secara manual (disarankan di awal,
  supaya kamu bisa cek dulu sebelum dana keluar).
- **Rate limiting / anti-fraud tambahan** (device fingerprint, limit akun per device, dll)
  supaya tidak dibobol pakai banyak akun.

## Legal
Cek dulu apakah model bisnis semacam ini butuh izin (misalnya sebagai penyelenggara
sistem pembayaran) di negara/wilayah kamu operasi.
