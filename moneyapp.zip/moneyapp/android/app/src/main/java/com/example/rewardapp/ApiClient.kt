package com.example.rewardapp

import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

// GANTI dengan URL backend kamu setelah di-deploy (Railway, Render, VPS, dll)
const val BASE_URL = "https://your-backend-domain.com"

object ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    private val JSON = MediaType.get("application/json; charset=utf-8")

    var authToken: String? = null

    fun login(email: String, password: String, callback: (Boolean, JSONObject?) -> Unit) {
        val body = JSONObject().put("email", email).put("password", password).toString()
        post("$BASE_URL/auth/login", body, needsAuth = false, callback)
    }

    fun register(email: String, password: String, callback: (Boolean, JSONObject?) -> Unit) {
        val body = JSONObject().put("email", email).put("password", password).toString()
        post("$BASE_URL/auth/register", body, needsAuth = false, callback)
    }

    fun getStatus(callback: (Boolean, JSONObject?) -> Unit) {
        get("$BASE_URL/ads/status", callback)
    }

    fun requestWithdraw(amount: Int, destination: String, callback: (Boolean, JSONObject?) -> Unit) {
        val body = JSONObject().put("amount", amount).put("destination", destination).toString()
        post("$BASE_URL/withdraw", body, needsAuth = true, callback)
    }

    private fun post(url: String, jsonBody: String, needsAuth: Boolean, callback: (Boolean, JSONObject?) -> Unit) {
        val reqBuilder = Request.Builder().url(url).post(RequestBody.create(JSON, jsonBody))
        if (needsAuth) authToken?.let { reqBuilder.addHeader("Authorization", "Bearer $it") }

        client.newCall(reqBuilder.build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = callback(false, null)
            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string()
                val json = try { JSONObject(text ?: "{}") } catch (e: Exception) { null }
                callback(response.isSuccessful, json)
            }
        })
    }

    private fun get(url: String, callback: (Boolean, JSONObject?) -> Unit) {
        val reqBuilder = Request.Builder().url(url).get()
        authToken?.let { reqBuilder.addHeader("Authorization", "Bearer $it") }

        client.newCall(reqBuilder.build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = callback(false, null)
            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string()
                val json = try { JSONObject(text ?: "{}") } catch (e: Exception) { null }
                callback(response.isSuccessful, json)
            }
        })
    }
}
