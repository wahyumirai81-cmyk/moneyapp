package com.example.rewardapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val emailInput = findViewById<EditText>(R.id.emailInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val registerLink = findViewById<TextView>(R.id.registerLink)
        var isRegisterMode = false

        registerLink.setOnClickListener {
            isRegisterMode = !isRegisterMode
            loginButton.text = if (isRegisterMode) "Daftar" else "Masuk"
            registerLink.text = if (isRegisterMode) "Sudah punya akun? Masuk" else "Belum punya akun? Daftar"
        }

        loginButton.setOnClickListener {
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Email dan password wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val onResult: (Boolean, org.json.JSONObject?) -> Unit = { success, json ->
                runOnUiThread {
                    if (success && json != null) {
                        val token = json.getString("token")
                        val user = json.getJSONObject("user")
                        getSharedPreferences("session", MODE_PRIVATE).edit()
                            .putString("token", token)
                            .putString("user_id", user.getString("id"))
                            .apply()
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    } else {
                        val msg = json?.optString("error") ?: "Gagal, coba lagi"
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }

            if (isRegisterMode) ApiClient.register(email, password, onResult)
            else ApiClient.login(email, password, onResult)
        }
    }
}
