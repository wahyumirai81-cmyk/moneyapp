package com.example.rewardapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions

// GANTI dengan Ad Unit ID rewarded ad asli kamu dari AdMob console.
// ID di bawah ini adalah TEST ad unit resmi dari Google, aman dipakai saat development
// TAPI TIDAK MENGHASILKAN UANG. Ganti sebelum rilis production.
const val REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

class MainActivity : AppCompatActivity() {

    private var rewardedAd: RewardedAd? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var balanceText: TextView
    private lateinit var watchAdButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("session", MODE_PRIVATE)
        val token = prefs.getString("token", null)
        val userId = prefs.getString("user_id", null)

        if (token == null || userId == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        ApiClient.authToken = token

        MobileAds.initialize(this)

        balanceText = findViewById(R.id.balanceText)
        watchAdButton = findViewById(R.id.watchAdButton)
        val withdrawButton = findViewById<Button>(R.id.withdrawButton)

        watchAdButton.setOnClickListener { showRewardedAd(userId) }
        withdrawButton.setOnClickListener {
            startActivity(Intent(this, WithdrawActivity::class.java))
        }

        loadStatus()
        loadRewardedAd(userId)
    }

    private fun loadStatus() {
        ApiClient.getStatus { success, json ->
            runOnUiThread {
                if (success && json != null) {
                    val balance = json.optInt("balance", 0)
                    val watched = json.optInt("ads_watched_today", 0)
                    val max = json.optInt("max_ads_per_day", 0)
                    balanceText.text = "Saldo: Rp$balance\nIklan hari ini: $watched/$max"
                    watchAdButton.isEnabled = watched < max
                } else {
                    Toast.makeText(this, "Gagal memuat status", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadRewardedAd(userId: String) {
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(this, REWARDED_AD_UNIT_ID, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                // user_id dikirim sebagai custom data supaya callback SSV di backend
                // tahu iklan ini punya siapa, lalu backend yang menambah saldo
                // — BUKAN app, supaya tidak bisa dicurangi.
                val options = ServerSideVerificationOptions.Builder()
                    .setCustomData(userId)
                    .build()
                ad.setServerSideVerificationOptions(options)
                rewardedAd = ad
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                rewardedAd = null
            }
        })
    }

    private fun showRewardedAd(userId: String) {
        val ad = rewardedAd
        if (ad == null) {
            Toast.makeText(this, "Iklan belum siap, coba lagi sebentar", Toast.LENGTH_SHORT).show()
            loadRewardedAd(userId)
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                loadRewardedAd(userId)
                // Saldo di-refresh dari server, karena penambahan saldo yang SAH
                // terjadi lewat callback SSV ke backend, bukan langsung di app.
                loadStatus()
            }
        }

        ad.show(this) { /* reward callback lokal, saldo tetap sumber kebenarannya dari backend */ }
    }
}
