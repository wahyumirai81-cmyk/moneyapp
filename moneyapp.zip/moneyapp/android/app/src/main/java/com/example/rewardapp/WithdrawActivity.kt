package com.example.rewardapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class WithdrawActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_withdraw)

        val amountInput = findViewById<EditText>(R.id.amountInput)
        val destinationInput = findViewById<EditText>(R.id.destinationInput)
        val submitButton = findViewById<Button>(R.id.submitWithdrawButton)

        submitButton.setOnClickListener {
            val amount = amountInput.text.toString().toIntOrNull()
            val destination = destinationInput.text.toString().trim()

            if (amount == null || destination.isEmpty()) {
                Toast.makeText(this, "Isi jumlah & tujuan e-wallet/rekening dengan benar", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            ApiClient.requestWithdraw(amount, destination) { success, json ->
                runOnUiThread {
                    val msg = json?.optString(if (success) "message" else "error")
                        ?: "Terjadi kesalahan"
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    if (success) finish()
                }
            }
        }
    }
}
