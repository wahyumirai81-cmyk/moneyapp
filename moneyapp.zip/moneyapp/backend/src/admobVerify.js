// Verifikasi Server-Side Verification (SSV) callback dari AdMob.
// Ini WAJIB dipakai kalau mau reward-nya beneran anti-curang,
// karena tanpa ini, orang bisa panggil endpoint reward tanpa benar-benar nonton iklan.
// Dokumentasi resmi: https://developers.google.com/admob/android/ssv

const crypto = require('crypto');

let cachedKeys = null;
let cachedAt = 0;

async function getGoogleKeys() {
  const now = Date.now();
  if (cachedKeys && now - cachedAt < 1000 * 60 * 60) return cachedKeys;

  const resp = await fetch('https://www.gstatic.com/admob/reward/verifier-keys.json');
  const json = await resp.json();
  cachedKeys = json.keys;
  cachedAt = now;
  return cachedKeys;
}

// query: seluruh query string asli dari request AdMob callback
async function verifyAdMobCallback(query) {
  const params = new URLSearchParams(query);
  const signature = params.get('signature');
  const keyId = params.get('key_id');
  if (!signature || !keyId) return { valid: false, reason: 'Parameter signature/key_id tidak ada' };

  const content = query.split('&signature=')[0];

  const keys = await getGoogleKeys();
  const key = keys.find((k) => String(k.keyId) === String(keyId));
  if (!key) return { valid: false, reason: 'Key ID tidak ditemukan' };

  const verifier = crypto.createVerify('SHA256');
  verifier.update(content);
  const publicKey = crypto.createPublicKey({
    key: Buffer.from(key.pem || key.base64, key.pem ? 'utf8' : 'base64'),
    format: key.pem ? 'pem' : 'der',
    type: 'spki',
  });

  const sigBuffer = Buffer.from(signature.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
  const valid = verifier.verify(publicKey, sigBuffer);

  return { valid, params: Object.fromEntries(params) };
}

module.exports = { verifyAdMobCallback };
