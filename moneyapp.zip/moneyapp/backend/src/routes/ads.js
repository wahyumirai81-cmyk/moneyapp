const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { requireAuth } = require('../authMiddleware');
const { verifyAdMobCallback } = require('../admobVerify');

const router = express.Router();

const REWARD_PER_AD = parseInt(process.env.REWARD_PER_AD || '500', 10);
const MAX_ADS_PER_DAY = 50; // batas wajar biar tidak dibobol / rugi terus

function today() {
  return new Date().toISOString().slice(0, 10);
}

// Endpoint dipanggil oleh Google AdMob langsung ke server (bukan dari app),
// setelah user selesai nonton rewarded ad sampai habis.
// URL callback ini didaftarkan di AdMob console > Rewarded Ads > Server-side verification.
router.get('/admob-callback', async (req, res) => {
  const rawQuery = req.url.split('?')[1] || '';
  const check = await verifyAdMobCallback(rawQuery);

  if (!check.valid) {
    return res.status(400).send('invalid signature');
  }

  const { user_id: userId, transaction_id: txId } = check.params;
  if (!userId || !txId) return res.status(400).send('missing params');

  const existing = db.prepare('SELECT id FROM ad_rewards WHERE ad_transaction_id = ?').get(txId);
  if (existing) return res.status(200).send('already processed');

  const d = today();
  const counter = db.prepare('SELECT count FROM daily_ad_counter WHERE user_id = ? AND date = ?').get(userId, d);
  const currentCount = counter ? counter.count : 0;

  if (currentCount >= MAX_ADS_PER_DAY) {
    return res.status(200).send('daily limit reached, not rewarded');
  }

  const txDb = db.transaction(() => {
    db.prepare(
      'INSERT INTO ad_rewards (id, user_id, amount, ad_transaction_id, verified) VALUES (?, ?, ?, ?, 1)'
    ).run(uuidv4(), userId, REWARD_PER_AD, txId);

    db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(REWARD_PER_AD, userId);

    db.prepare(
      `INSERT INTO daily_ad_counter (user_id, date, count) VALUES (?, ?, 1)
       ON CONFLICT(user_id, date) DO UPDATE SET count = count + 1`
    ).run(userId, d);
  });
  txDb();

  res.status(200).send('ok');
});

// Dipanggil dari app untuk cek saldo terkini & berapa iklan tersisa hari ini
router.get('/status', requireAuth, (req, res) => {
  const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(req.userId);
  const counter = db
    .prepare('SELECT count FROM daily_ad_counter WHERE user_id = ? AND date = ?')
    .get(req.userId, today());

  res.json({
    balance: user.balance,
    ads_watched_today: counter ? counter.count : 0,
    max_ads_per_day: MAX_ADS_PER_DAY,
    reward_per_ad: REWARD_PER_AD,
  });
});

module.exports = router;
