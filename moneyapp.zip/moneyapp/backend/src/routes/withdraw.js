const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { requireAuth } = require('../authMiddleware');

const router = express.Router();

const MIN_WITHDRAW = parseInt(process.env.MIN_WITHDRAW || '1000', 10);
const MAX_WITHDRAW = parseInt(process.env.MAX_WITHDRAW || '100000', 10);

router.post('/', requireAuth, (req, res) => {
  const { amount, destination } = req.body;

  if (!destination || typeof destination !== 'string') {
    return res.status(400).json({ error: 'Nomor e-wallet/rekening tujuan wajib diisi' });
  }
  if (!Number.isInteger(amount) || amount < MIN_WITHDRAW || amount > MAX_WITHDRAW) {
    return res.status(400).json({
      error: `Jumlah withdraw harus antara Rp${MIN_WITHDRAW} - Rp${MAX_WITHDRAW}`,
    });
  }

  const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(req.userId);
  if (user.balance < amount) {
    return res.status(400).json({ error: 'Saldo tidak cukup' });
  }

  const id = uuidv4();
  const txDb = db.transaction(() => {
    db.prepare('UPDATE users SET balance = balance - ? WHERE id = ?').run(amount, req.userId);
    db.prepare(
      'INSERT INTO withdrawals (id, user_id, amount, destination, status) VALUES (?, ?, ?, ?, ?)'
    ).run(id, req.userId, amount, destination, 'pending');
  });
  txDb();

  // TODO: setelah ini, panggil API payment gateway (Xendit/Midtrans/Tripay) untuk
  // benar-benar mencairkan dana ke `destination`, lalu update status jadi 'processing'/'success'/'failed'.
  // Jangan langsung tandai 'success' sebelum konfirmasi dari gateway berhasil.

  res.json({ id, status: 'pending', message: 'Permintaan withdraw diterima, sedang diproses' });
});

router.get('/history', requireAuth, (req, res) => {
  const rows = db
    .prepare('SELECT id, amount, destination, status, created_at, processed_at FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC')
    .all(req.userId);
  res.json(rows);
});

module.exports = router;
